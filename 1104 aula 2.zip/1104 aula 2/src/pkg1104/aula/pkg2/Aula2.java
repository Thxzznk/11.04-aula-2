/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg1104.aula.pkg2;

import javax.swing.JOptionPane;

/**
 *
 * @author thierry.smsantos
 */
public class Aula2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //JOptionPane.showMessageDialog(null,"deu erro ai irmao");
        //JOptionPane.showMessageDialog(null,"viu irmao");
        JOptionPane.showInputDialog(null,"qual seu nome?");
        JOptionPane.showInputDialog(null,"qual sua idade");
        JOptionPane.showConfirmDialog(null,"quer estudar aqui?");
        
    
}
}